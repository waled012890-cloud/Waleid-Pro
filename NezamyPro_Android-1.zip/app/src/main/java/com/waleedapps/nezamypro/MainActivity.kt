package com.waleedapps.nezamypro

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Ink = Color(0xFF101114)
private val Panel = Color(0xFF1C1E23)
private val Gold = Color(0xFFD6B15E)
private val Muted = Color(0xFF9DA3AE)
private val White = Color(0xFFF7F4EC)

data class Entry(val section: String, val title: String, val amount: Double, val note: String, val date: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NezamyApp() }
    }
}

@Composable
fun NezamyApp() {
    val context = LocalContext.current
    var selected by remember { mutableStateOf("الرئيسية") }
    var entries by remember { mutableStateOf(loadEntries(context)) }
    var showAdd by remember { mutableStateOf(false) }
    val sections = listOf("الرئيسية", "مصروفاتي", "ديوني", "التزاماتي", "مهامي", "مواعيدي", "أهدافي", "مشترياتي", "تقاريري", "الإعدادات")
    val income = entries.filter { it.section == "دخل" }.sumOf { it.amount }
    val expense = entries.filter { it.section == "مصروف" }.sumOf { it.amount }
    val balance = income - expense

    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Gold, onPrimary = Ink,
        onBackground = White, onSurface = White, secondary = Gold
    )) {
        Scaffold(
            containerColor = Ink,
            floatingActionButton = {
                if (selected != "الإعدادات" && selected != "تقاريري") {
                    FloatingActionButton(onClick = { showAdd = true }, containerColor = Gold, contentColor = Ink) {
                        Icon(Icons.Default.Add, contentDescription = "إضافة")
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Gold) {
                    listOf("الرئيسية", "مصروفاتي", "ديوني", "الإعدادات").forEach { item ->
                        NavigationBarItem(
                            selected = selected == item,
                            onClick = { selected = item },
                            icon = { Icon(when(item) {
                                "الرئيسية" -> Icons.Default.Home
                                "مصروفاتي" -> Icons.Default.AccountBalanceWallet
                                "ديوني" -> Icons.Default.People
                                else -> Icons.Default.Settings
                            }, contentDescription = item) },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, indicatorColor = Gold.copy(alpha = .15f), selectedTextColor = Gold)
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("نظامي PRO", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("Waleed Apps", color = Muted, fontSize = 12.sp)
                    }
                    Text("إدارة حياتك بذكاء", color = Muted, fontSize = 12.sp)
                }
                when (selected) {
                    "الرئيسية" -> Dashboard(balance, income, expense, entries) { selected = it }
                    "مصروفاتي" -> EntriesScreen("الحركة المالية", entries.filter { it.section == "دخل" || it.section == "مصروف" }, context) { entries = loadEntries(context) }
                    "ديوني" -> EntriesScreen("الديون والمستحقات", entries.filter { it.section == "دين ليا" || it.section == "دين عليا" }, context) { entries = loadEntries(context) }
                    "الإعدادات" -> SettingsScreen(context)
                    "تقاريري" -> ReportsScreen(income, expense, entries.size)
                    else -> EntriesScreen(selected, entries.filter { it.section == selected }, context) { entries = loadEntries(context) }
                }
            }
        }
        if (showAdd) AddEntryDialog(selected, onDismiss = { showAdd = false }) { entry ->
            entries = entries + entry
            saveEntries(context, entries)
            showAdd = false
        }
    }
}

@Composable
fun Dashboard(balance: Double, income: Double, expense: Double, entries: List<Entry>, go: (String) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("الرصيد الصافي المسجل", color = Muted)
                    Text(money(balance), color = Gold, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Summary("إجمالي الدخل", income, Color(0xFF72C99A))
                        Summary("المصروفات", expense, Color(0xFFE58B83))
                    }
                }
            }
        }
        item { Text("أقسام نظامك", color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        items(listOf("مصروفاتي", "ديوني", "التزاماتي", "مهامي", "مواعيدي", "أهدافي", "مشترياتي", "تقاريري")) { name ->
            Card(Modifier.fillMaxWidth().clickable { go(name) }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = Gold)
                    Spacer(Modifier.width(8.dp))
                    Text(name, color = White, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.ArrowBackIosNew, contentDescription = null, tint = Muted)
                }
            }
        }
        item { Text("آخر العمليات", color = Muted, fontSize = 13.sp) }
        items(entries.takeLast(5).reversed()) { e -> EntryCard(e) }
    }
}

@Composable
fun Summary(label: String, amount: Double, color: Color) {
    Column {
        Text(label, color = Muted, fontSize = 12.sp)
        Text(money(amount), color = color, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

@Composable
fun EntriesScreen(title: String, entries: List<Entry>, context: Context, refresh: () -> Unit) {
    Column {
        Text(title, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))
        if (entries.isEmpty()) Text("لا توجد بيانات بعد. اضغط + لإضافة أول سجل.", color = Muted, modifier = Modifier.padding(top = 24.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(entries.reversed()) { e -> EntryCard(e) }
        }
    }
}

@Composable
fun EntryCard(e: Entry) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(e.title, color = White, fontWeight = FontWeight.SemiBold)
                Text(e.section + if (e.note.isNotBlank()) " • " + e.note else "", color = Muted, fontSize = 11.sp)
            }
            Text(money(e.amount), color = Gold, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AddEntryDialog(section: String, onDismiss: () -> Unit, onSave: (Entry) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(if (section == "ديوني") "دين ليا" else "مصروف") }
    val options = when(section) {
        "ديوني" -> listOf("دين ليا", "دين عليا")
        "مصروفاتي", "الرئيسية" -> listOf("دخل", "مصروف")
        else -> listOf(section)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("إضافة سجل", color = Gold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("نوع السجل", color = Muted)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    options.forEach { opt ->
                        FilterChip(selected = type == opt, onClick = { type = opt }, label = { Text(opt, fontSize = 11.sp) })
                    }
                }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("الاسم أو البيان") }, singleLine = true)
                OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("المبلغ") }, singleLine = true)
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("ملاحظات") }, singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = {
            val value = amount.toDoubleOrNull()
            if (title.isNotBlank() && value != null && value >= 0) onSave(Entry(type, title.trim(), value, note.trim(), System.currentTimeMillis()))
        }) { Text("حفظ", color = Gold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun ReportsScreen(income: Double, expense: Double, count: Int) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("تقاريرك", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Summary("إجمالي الدخل", income, Color(0xFF72C99A))
        Summary("إجمالي المصروفات", expense, Color(0xFFE58B83))
        Summary("عدد السجلات", count.toDouble(), Gold)
        Text("الأرقام هنا مبنية على السجلات المحفوظة محليًا.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun SettingsScreen(context: Context) {
    var dark by remember { mutableStateOf(true) }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("الإعدادات", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("المظهر", color = Gold, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("الوضع الداكن", color = White, modifier = Modifier.weight(1f))
            Switch(checked = dark, onCheckedChange = { dark = it })
        }
        Text("النسخ الاحتياطي", color = Gold, fontWeight = FontWeight.Bold)
        Text("بياناتك محفوظة على هذا الجهاز. لا تحذف بيانات التطبيق قبل تصدير نسخة احتياطية.", color = Muted)
        Text("الإصدار 1.0.0", color = Muted)
        Text("تطوير Waleed Apps", color = Gold)
    }
}

private fun money(v: Double) = String.format(java.util.Locale("ar", "EG"), "%.2f ج.م", v)

private fun loadEntries(context: Context): List<Entry> {
    val raw = context.getSharedPreferences("nezamy", Context.MODE_PRIVATE).getString("entries", "[]") ?: "[]"
    val arr = JSONArray(raw)
    return (0 until arr.length()).mapNotNull { i ->
        runCatching {
            val o = arr.getJSONObject(i)
            Entry(o.getString("section"), o.getString("title"), o.getDouble("amount"), o.optString("note"), o.optLong("date"))
        }.getOrNull()
    }
}

private fun saveEntries(context: Context, entries: List<Entry>) {
    val arr = JSONArray()
    entries.forEach { e ->
        arr.put(JSONObject().put("section", e.section).put("title", e.title).put("amount", e.amount).put("note", e.note).put("date", e.date))
    }
    context.getSharedPreferences("nezamy", Context.MODE_PRIVATE).edit().putString("entries", arr.toString()).apply()
}
